﻿using System;

namespace Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            RubleAccount rubleAccount = new RubleAccount();
            rubleAccount.Put = 200;
            double rub = rubleAccount.Rate;
            (string _valuta, int _balance) = rubleAccount.CheckBalace;
            Console.WriteLine($"rub {rub.ToString()}");
            Console.WriteLine($"balance {_valuta} {_balance.ToString()}");
            Console.WriteLine($"Rate {rubleAccount.Rate}");
            Console.WriteLine(value: $"Info {rubleAccount.Info()}");
        }

        

    }

    interface IRealMoneyInterface
    {
        void PrintMoney();
    }

    interface IVirtualMoneyInterface
    {
        void PrintMoney();
    }


    public abstract class Check
    {
        // Счет базовый, абстрактный класс (родительский)
        private int _money;
        private static string _valuta;

        public Check()
        {
            _money = 0;
            _valuta = "RUB";
        }

        public int Put
        {
            // Получить, положить на счет
            get => this._money;

            set
            {
                this._money += value;
            }
        }


        public string ChangeValuta
        {
            // Изменить валюту, получить текущую валюту
            get => _valuta;

            set => _valuta = value;
        }

        public virtual (string Valuta, int Balance) CheckBalace
        {
            // Проверить баланс
            get => ("", this._money);
        }

        public virtual string CheckValuta
        {
            // Проверить валюту (узнать)
            get => _valuta;
        }


        // Курс валюты
        public abstract double Rate { get; }

        ~Check()
        {
            Console.WriteLine("Instance of class Check destroyed");
        }
    }

    public class RubleAccount : Check, IRealMoneyInterface, IVirtualMoneyInterface
    {
        // Дочерний класс, рублевый счет (наследник)
        public delegate void Link(LinkEventArgs e);
        public static event Link ShowLink;
        // public event EventHandler ShowLink;

        void IRealMoneyInterface.PrintMoney()
        {
            Console.WriteLine("Валюта");
            Console.WriteLine(Put);
        }

        void IVirtualMoneyInterface.PrintMoney()
        {
            Console.WriteLine("Виртуальная валюта");
            Console.WriteLine(Put);
        }
        
        
        public override (string Valuta, int Balance) CheckBalace
        {
            // Проверка валюты
            get
            {
                return ("RU", Put);
            }
        }

        public override double Rate
        {
            // Получить курс валюты
            get => Put * 0.013;
        }

        public static void LinkConsultant(EventArgs text)
        {
            Console.WriteLine("Link: http://www.consultant.ru/document/cons_doc_LAW_2201/4b6b5df9fd5c11e890228a3c0fb76e0097d341a6/");
        }

        public string Info()
        {
            string text = "Специальные (рублёвые) счета – это счета, которые были открыты в уполномоченных офисах Сбербанка путём приёма от клиентов чеков всесоюзного объединения «Внешпосылторг» или путём зачисления рублёвого покрытия, поступившего с валютных счетов во Внешэкономбанке СССР.";
            LinkEventArgs args = new LinkEventArgs();
            args.Text = text;
            ShowLink += LinkConsultant;
            ShowLink(args);
            return text;
        }

       
    }

    public class LinkEventArgs : EventArgs
    {
        public string Text { get; set; }
    }

    public class ForeignAccount : Check
    {
        // Дочерний класс, валютный счет (наследник)
        public override (string Valuta, int Balance) CheckBalace
        {
            get
            {
                return ("ALL", Put);
            }
        }

        public override double Rate
        {
            get => Put * 0.15;
        }

        public delegate void ShowInfo();

        // ShowInfo showInfo = new ShowInfo(Info);


        public static void Info() => Console.WriteLine("Счет 52 'Валютные счета' предназначен для обобщения информации о наличии и движении денежных средств в иностранных валютах на валютных счетах организации, открытых в кредитных организациях на территории Российской Федерации и за ее пределами.");

        public static void LinkConsultant() => Console.WriteLine("Link: http://www.consultant.ru/document/cons_doc_LAW_66752/6708e429ee36c23fb3ffe408794640f3cc483213/#:~:text=%D0%A1%D1%87%D0%B5%D1%82%2052%20%22%D0%92%D0%B0%D0%BB%D1%8E%D1%82%D0%BD%D1%8B%D0%B5%20%D1%81%D1%87%D0%B5%D1%82%D0%B0%22%20%D0%BF%D1%80%D0%B5%D0%B4%D0%BD%D0%B0%D0%B7%D0%BD%D0%B0%D1%87%D0%B5%D0%BD,%D0%A4%D0%B5%D0%B4%D0%B5%D1%80%D0%B0%D1%86%D0%B8%D0%B8%20%D0%B8%20%D0%B7%D0%B0%20%D0%B5%D0%B5%20%D0%BF%D1%80%D0%B5%D0%B4%D0%B5%D0%BB%D0%B0%D0%BC%D0%B8.");

       

        public static event ShowInfo PrintInfo;

    }
}
