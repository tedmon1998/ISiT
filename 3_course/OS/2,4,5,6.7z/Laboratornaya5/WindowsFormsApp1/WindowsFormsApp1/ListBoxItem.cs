﻿using System.Windows.Forms;

namespace WindowsFormsApp1
{
    internal class ListBoxItem
    {
        public HorizontalAlignment HorizontalAlignment { get; internal set; }
    }
}